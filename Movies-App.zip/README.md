Movies-App

Prerequistes
-Nodejs and npm installed on machine

Installation
Download zip named Movies-App and unzip it on your local machine
Navigate to the project directory in your terminal
Run 'npm install' to install your necessary dependencies
After installing dependencies, run npm start in your terminal
The application will start