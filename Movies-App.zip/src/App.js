import './App.css';
import {useEffect, useReducer, useRef, useState} from 'react';


const moviesReducer = (state,action) => {

  switch(action.type){

    case 'sortByPopularityDesc':
      return {
        ...state,
        data: [...action.payload].sort((a,b) => b.popularity - a.popularity).slice(0,20),
        apiData:  [...action.payload].sort((a,b) => b.popularity - a.popularity).slice(0,20),
        sortBy: 'PopularityByDesc'
      };
    case 'sortByPopularityAsc':
      return {
          ...state,
          data: [...state.data].sort((a,b) => a.popularity - b.popularity).slice(0,20),
          sortBy: 'sortByPopularityAsc'
      };
    case 'getGenreList':
        return {
            ...state,
            genreData: [...action.payload].map((genre)=> genre.id ? {...genre,status: 'inactive'} : ''),
            sortBy: 'getGenreList'
        };
    case 'updateGenreList':
      return{
        ...state,
        genreData: [...state.genreData].map((genre)=> genre.id === action.payload.id ? {...genre,status:action.payload.status} : genre )
      }
    case 'filterByGenre':
      return{
        ...state,
        data: [...state.apiData].filter((movie)=> action.payload.every(id => movie.genre_ids.includes(id))),
         sortBy: 'filterByGenre'
      }
    case 'nextYear':
        return {
            ...state,
            year: state.year + 1,
        };
      case 'prevYear':
          return {
              ...state,
            year: state.year - 1
        };
      default:
        return state
  }
}



function App() {
  const [movies,dispatch] = useReducer(moviesReducer,{
    data:[],
    genreData:[],
    sortBy: 'sortByPopularityDesc',
    year: 2012 
  });

  const selectedGenreList = useRef([])
  const [prevScrollY, setPrevScrollY] = useState(0);

  const [loading,setLoading] = useState(false);
  const [error,setError] = useState(false);


//fetching List og Movies
  async function fetchListOfMovies(selectedYear){
    try{
      setLoading(true)
      const rawMoviesList = await fetch(`https://api.themoviedb.org/3/discover/movie?api_key=2dca580c2a14b55200e784d157207b4d&sort_by=popularity.desc&primary_release_year=${selectedYear}&page=1&vote_count.gte=100`);

      if(rawMoviesList.ok){
        const movieList = await rawMoviesList.json();

        dispatch({type:'sortByPopularityDesc',payload:movieList.results })
      } 
    }catch(err){  
        setError(err)
    }
    finally{
      setLoading(false)
    }
  }

//fetching List of Genre

  async function fetchGenreForListOfMovies(){
    try{
      
      const rawGenreList  = await fetch('https://api.themoviedb.org/3/genre/movie/list?api_key=2dca580c2a14b55200e784d157207b4d&language=en');
      if(rawGenreList.ok){
        const genreList = await rawGenreList.json();

        dispatch({type:'getGenreList',payload: genreList.genres})
      }
    }
    catch(err){

    }
  }

  useEffect(()=>{
    fetchListOfMovies(movies.year);

  },[movies.year]);

  useEffect(()=>{
    fetchGenreForListOfMovies()
  },[])


  useEffect(()=>{

    const onScroll = () => {

      const currentScrollY = window.scrollY;

            // Scroll Down
            if (currentScrollY > prevScrollY && !loading) {
                if (window.innerHeight + currentScrollY >= document.body.offsetHeight) {
                  dispatch({type:'nextYear' })
                }
            }

            // Scroll up
            else if (currentScrollY < prevScrollY && !loading && currentScrollY === 0) {
              dispatch({type:'prevYear' })
            }

            setPrevScrollY(currentScrollY);
         
  
     }

    window.addEventListener('scroll',onScroll)
    return ()=> window.removeEventListener('scroll',onScroll)

  },[loading,prevScrollY])

  const handleFilterByGenre = (value) => {
  
    const newGenreData = movies.genreData.filter((movie)=> movie.name === value )[0];
    
    if(selectedGenreList.current.includes(newGenreData.id)){
      selectedGenreList.current = [...selectedGenreList.current.filter(genreList => genreList !== newGenreData.id)];
      dispatch({type:'updateGenreList', payload: {id:newGenreData.id ,status: 'inactive'} })

    }else{

      selectedGenreList.current = [...selectedGenreList.current, newGenreData.id]
      dispatch({type:'updateGenreList', payload: { id:newGenreData.id , status: 'active'} })

    }

    dispatch({type:'filterByGenre',payload: selectedGenreList.current })
  }

  console.log(movies,movies.genreData,'movie')
  return (
    <div className="App">

            <div className='filter-genre-wrapper'>
            { 
                movies.genreData.length > 0 && (       
                  movies.genreData.map((genre)=>(
                    <FilterByGenre key={genre.id}  name={genre.name} handleFilterByGenre={handleFilterByGenre} isActive={genre.status === 'active'}/>
                  ))  
              
                )    
            }
            </div>
          
          {loading && <p className='loading'>LOADING...</p>}
          {error && <p className='error'>Error</p>}
          {!loading && !error && ( 
            <CardList>
                {
                movies.data.length > 0 ?
                  (
                    movies.data.map((movie)=> (
                      <Card key={movie.id} imageUrl={movie.poster_path} title={movie.title} description={movie.overview} genericIds ={movie.genre_ids}/>
                    ))
                )
                :
                  <p className='resultTxt'> NO RESULTS</p>
                }
                
            </CardList>
          )}
    </div>
  );
}


const FilterByGenre = ({name,handleFilterByGenre,isActive}) => {

  const handleFilterChange = (selectedGenre)=> {
    handleFilterByGenre(selectedGenre)
  }

  return(
    <>
        <button className={isActive ? 'active' : 'inactive'}  onClick={()=>handleFilterChange(name)}> {name}</button>
    </>
  )
}


const CardList = ({children}) => {

  return(
    <div className='card-wrapper'>
      {children}
    </div>
  )
}

const Card = ({imageUrl,title,description,genericIds}) => {

  return(
    <>  
      <div className='card'>
          <img className='card-image' src={`https://image.tmdb.org/t/p/original/${imageUrl}`} alt=''/>
          <p className='card-title'>Title :{title}</p>
          <p className='card-desc'>Description: {description}</p>
          <ul className='generic-wrapper'>  Genre Ids
            {
              genericIds.map((generics,index) => {
                return(
                  <li className='card-generic' key={index}>id: {generics} </li>
                )
              })
            }
          </ul>
      </div>
    </>
  )
}

export default App;
